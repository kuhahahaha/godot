#!/usr/bin/env python3
"""Independently decode frozen PNG evidence and audit camera RED/GREEN logs.

Python standard library only. Never invokes Godot, the GPU, or fixture runners.
Supports PNG 8-bit RGB/RGBA, noninterlaced, validates every chunk CRC, and
reconstructs all five PNG scanline filters before expanding RGB to opaque RGBA.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import zlib

EXPECTED_CHECKS = set('''actual_viewport_1 actual_viewport_2 actual_viewport_freed
camera_payload_1 camera_payload_2 complete_token_1 complete_token_2
invalidated_cache_null new_ref_and_token old_payload_immutable old_ref_released
old_ref_retained old_ref_survives_free old_ref_survives_invalidate
presentation_1 presentation_2 production_cache_nonnull_1 production_cache_nonnull_2
real_viewport_0 real_viewport_1 real_viewport_2 registered_1 registered_2
unregistered_cache_null'''.split())
RED_FALSE = {'production_cache_nonnull_1', 'production_cache_nonnull_2',
             'old_ref_survives_free', 'old_ref_survives_invalidate'}
RED_TRUE = {'actual_viewport_freed', 'invalidated_cache_null', 'old_ref_released',
            'real_viewport_0', 'real_viewport_1', 'real_viewport_2', 'registered_1',
            'registered_2', 'unregistered_cache_null'}
METHODS = {'mobile': 'Forward Mobile', 'forward_plus': 'Forward+'}
PREFIX = 'CAMERA_NATIVE_PROPAGATION '


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def paeth(left, up, upper_left):
    predictor = left + up - upper_left
    distances = (abs(predictor - left), abs(predictor - up), abs(predictor - upper_left))
    return (left, up, upper_left)[distances.index(min(distances))]


def decode_png(data):
    require(data[:8] == b'\x89PNG\r\n\x1a\n', 'PNG signature')
    offset = 8
    chunks = []
    compressed = bytearray()
    header = None
    ended = False
    while offset < len(data):
        require(offset + 12 <= len(data), 'truncated chunk header')
        length = struct.unpack_from('>I', data, offset)[0]
        kind = data[offset + 4:offset + 8]
        require(offset + 12 + length <= len(data), 'truncated chunk payload')
        payload = data[offset + 8:offset + 8 + length]
        crc = struct.unpack_from('>I', data, offset + 8 + length)[0]
        require(zlib.crc32(kind + payload) & 0xffffffff == crc, 'PNG CRC mismatch')
        chunks.append(kind.decode('ascii'))
        if kind == b'IHDR':
            require(header is None and len(chunks) == 1 and length == 13, 'invalid IHDR')
            header = struct.unpack('>IIBBBBB', payload)
        elif kind == b'IDAT':
            require(header is not None, 'IDAT before IHDR')
            compressed.extend(payload)
        elif kind == b'IEND':
            require(length == 0, 'invalid IEND')
            ended = True
            offset += 12
            break
        else:
            require(kind[0] & 32 != 0 or kind == b'PLTE', 'unsupported critical chunk')
            # tRNS would change RGB alpha; fail rather than silently ignoring it.
            require(kind != b'tRNS', 'RGB transparency chunk unsupported')
        offset += length + 12
    require(ended and offset == len(data) and header is not None, 'missing IEND/trailing bytes')
    width, height, depth, color, compression, filtering, interlace = header
    require(width > 0 and height > 0 and depth == 8 and color in (2, 6), 'requires 8-bit RGB/RGBA')
    require((compression, filtering, interlace) == (0, 0, 0), 'requires standard noninterlaced PNG')
    bpp = 3 if color == 2 else 4
    stride = width * bpp
    inflater = zlib.decompressobj()
    raw = inflater.decompress(bytes(compressed)) + inflater.flush()
    require(inflater.eof and not inflater.unused_data, 'invalid zlib stream')
    require(len(raw) == height * (stride + 1), 'wrong scanline byte count')
    previous = bytearray(stride)
    decoded = bytearray()
    filters = set()
    for row_number in range(height):
        pos = row_number * (stride + 1)
        filter_type = raw[pos]
        require(0 <= filter_type <= 4, 'invalid scanline filter')
        filters.add(filter_type)
        row = bytearray(raw[pos + 1:pos + 1 + stride])
        for index in range(stride):
            left = row[index - bpp] if index >= bpp else 0
            up = previous[index]
            upper_left = previous[index - bpp] if index >= bpp else 0
            predictor = (0, left, up, (left + up) // 2, paeth(left, up, upper_left))[filter_type]
            row[index] = (row[index] + predictor) & 255
        decoded.extend(row)
        previous = row
    if color == 2:
        rgba = bytearray()
        for pos in range(0, len(decoded), 3):
            rgba.extend(decoded[pos:pos + 3])
            rgba.append(255)
        decoded = rgba
    return width, height, bytes(decoded), {'color_type': color, 'filters': sorted(filters),
                                           'chunks': chunks, 'all_chunk_crcs_valid': True}


def decoder_self_test():
    def chunk(kind, payload):
        return struct.pack('>I', len(payload)) + kind + payload + struct.pack('>I', zlib.crc32(kind + payload) & 0xffffffff)
    checks = []
    for channels, color in ((3, 2), (4, 6)):
        width, height = 3, 5
        pixels = bytes((index * 37 + index // 4 * 11) % 256 for index in range(width * height * channels))
        stream = bytearray()
        stride = width * channels
        for y in range(height):
            current = pixels[y * stride:(y + 1) * stride]
            previous = pixels[(y - 1) * stride:y * stride] if y else bytes(stride)
            stream.append(y)
            for x, value in enumerate(current):
                left = current[x - channels] if x >= channels else 0
                up = previous[x]
                corner = previous[x - channels] if x >= channels else 0
                # Independent filter encoding expressions for the known rows.
                if y == 0:
                    predictor = 0
                elif y == 1:
                    predictor = left
                elif y == 2:
                    predictor = up
                elif y == 3:
                    predictor = (left + up) // 2
                else:
                    estimate = left + up - corner
                    ranked = [(abs(estimate - left), 0, left), (abs(estimate - up), 1, up), (abs(estimate - corner), 2, corner)]
                    predictor = min(ranked)[2]
                stream.append((value - predictor) % 256)
        png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, color, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(stream)) + chunk(b'IEND', b'')
        w, h, rgba, metadata = decode_png(png)
        expected = pixels if channels == 4 else b''.join(pixels[i:i + 3] + b'\xff' for i in range(0, len(pixels), 3))
        require((w, h, rgba) == (width, height, expected) and metadata['filters'] == [0, 1, 2, 3, 4], 'decoder self-test')
        corrupt = bytearray(png)
        corrupt[29] ^= 1
        try:
            decode_png(bytes(corrupt))
        except ValueError as error:
            require('CRC' in str(error), 'CRC rejection self-test')
        else:
            raise ValueError('CRC corruption accepted')
        checks.append({'color_type': color, 'filters_0_to_4': True, 'known_rgba_equal': True, 'crc_corruption_rejected': True})
    return checks


def log_text(path):
    data = path.read_bytes()
    text = data.decode()
    require(not re.search(r'\b(?:ERROR|WARNING):', text), f'diagnostics: {path}')
    require('TIMEOUT' not in text, f'timeout marker: {path}')
    return text, {'path': str(path.resolve()), 'sha256': sha(data), 'diagnostics_absent': True}


def parse_lines(text, prefix):
    return [json.loads(line[len(prefix):]) for line in text.splitlines() if line.startswith(prefix)]


def image_review(value, expected_dir, records):
    path = Path(value['path'])
    require(path.is_absolute() and expected_dir.resolve() in path.resolve().parents, f'image path outside evidence: {path}')
    data = path.read_bytes()
    width, height, rgba, metadata = decode_png(data)
    require((width, height) == (128, 128), f'image dimensions: {path}')
    count = sum(rgba[pos:pos + 4] != rgba[:4] for pos in range(0, len(rgba), 4))
    rgba_hash = sha(rgba)
    require(value['saved'] is True and value['width'] == width and value['height'] == height, f'report image shape: {path}')
    require(value['sha256'] == rgba_hash, f'report RGBA hash mismatch: {path}')
    require(type(value['nonuniform_pixels']) is int and value['nonuniform_pixels'] == count and 0 < count < width * height, f'nonuniform count mismatch: {path}')
    records.append({'path': str(path.resolve()), 'png_sha256': sha(data), 'rgba_sha256': rgba_hash,
                    'width': width, 'height': height, 'rgba_bytes': len(rgba), 'nonuniform_pixels': count,
                    'reported_hash_and_count_match': True, **metadata})
    return rgba


def camera_review(evidence, green, records):
    label = 'RETAIN_RESTORED_GPU' if green else 'RETAIN_OMITTED_GPU'
    directory = evidence / ('retain_restored_gpu' if green else 'retain_omitted_gpu')
    text, log_identity = log_text(evidence / (label + '.log'))
    process_path = evidence / (label + '_RESULT.json')
    process = json.loads(process_path.read_text())
    require(process['exit_code'] == (0 if green else 1) and 0 < process['seconds'] < 90, f'process result: {label}')
    log_identity['process_result_sha256'] = sha(process_path.read_bytes())
    reports = parse_lines(text, PREFIX)
    cases = parse_lines(text, 'CAMERA_NATIVE_PROPAGATION_CASE ')
    commands = parse_lines(text, 'COMMAND ')
    require(len(reports) == len(cases) == len(commands) == 2, f'case counts: {label}')
    require(set(case['method'] for case in cases) == set(METHODS), f'method set: {label}')
    by_method = {}
    result = {'log': log_identity, 'runner_exit_code': process['exit_code'], 'seconds': process['seconds'], 'backends': {}}
    for report in reports:
        method = Path(report['images']['first']['path']).parent.name
        require(method in METHODS and method not in by_method, f'report backend: {label}')
        require(report['authority'] == 'test-source-only-no-view-grant-accepted-authority' and report['stage'] == 4, f'authority/stage: {label}/{method}')
        checks = report['checks']
        if green:
            require(set(checks) == EXPECTED_CHECKS and len(checks) == 24 and all(v is True for v in checks.values()) and report['pass'] is True, f'GREEN checks: {method}')
        else:
            require(set(checks) == RED_TRUE | RED_FALSE and report['pass'] is False, f'RED check names/pass: {method}')
            require(all(checks[key] is False for key in RED_FALSE) and all(checks[key] is True for key in RED_TRUE), f'RED target failure: {method}')
        case = next(value for value in cases if value['method'] == method)
        expected_exit = 0 if green else 1
        require(case['exit_code'] == expected_exit and case['pass'] is green, f'backend process status: {method}')
        startup = re.findall(rf'^Metal [0-9.]+ - {re.escape(METHODS[method])} - Using Device #[0-9]+: .+$', text, re.M)
        require(len(startup) == 1 and case['renderer_device'] == startup, f'real renderer: {method}')
        command = next(cmd for cmd in commands if cmd[cmd.index('--rendering-method') + 1] == method)
        require(command[command.index('--rendering-driver') + 1] == 'metal' and '--headless' not in command, f'real GPU command: {method}')
        require(set(report['images']) == {'unregistered', 'first', 'second'}, f'image labels: {method}')
        images = {}
        for image_label, value in report['images'].items():
            require(value['draw_calls'] == 1, f'expected normal one-draw scene: {method}/{image_label}')
            images[image_label] = image_review(value, directory / method, records)
        require(images['first'] != images['second'], f'moved camera image unchanged: {method}')
        require(images['unregistered'] == images['first'], f'registration changed ordinary scene: {method}')
        if green:
            first, second = report['observation_1'], report['observation_2']
            for index, observation in ((1, first), (2, second)):
                require(observation['view_id'] == 0x43414d and observation['view_epoch'] == 1 and observation['present_seq'] == index, f'observation identity: {method}')
                require(observation['viewport_rid'] == observation['payload_viewport_rid'] and observation['viewport_rid'] > 0 and observation['camera_transform'] == observation['expected_transform'], f'actual source/transform: {method}')
            require(first['viewport_rid'] == second['viewport_rid'] and second['capture_ordinal'] > first['capture_ordinal'] > 0 and first['capture_object_id'] != second['capture_object_id'] and first['camera_transform'] != second['camera_transform'], f'new sample observation: {method}')
        by_method[method] = images
        result['backends'][method] = {'renderer_device': startup[0], 'exit_code': expected_exit,
                                      'all_24_checks_true': green, 'target_cache_false': not green,
                                      'false_checks': sorted(key for key, value in checks.items() if value is False),
                                      'all_images_one_draw': True, 'camera_image_changed': True,
                                      'registration_image_unchanged': True}
    require(set(by_method) == set(METHODS), 'missing camera backend')
    require(('CAMERA_NATIVE_PROPAGATION_MATRIX_PASS' in text) is green, 'runner matrix marker')
    return by_method, result


def viewport_review(evidence, records):
    text, identity = log_text(evidence / 'FINAL_VIEWPORT_GPU.log')
    process_path = evidence / 'FINAL_VIEWPORT_GPU_RESULT.json'
    process = json.loads(process_path.read_text())
    require(process['exit_code'] == 0 and 0 < process['seconds'] < 90, 'viewport runner process')
    identity['process_result_sha256'] = sha(process_path.read_bytes())
    reports = parse_lines(text, 'SCENE_VIEWPORT_INVARIANCE_NATIVE ')
    require(len(reports) == 2 and 'SCENE_VIEWPORT_INVARIANCE_MATRIX_PASS' in text, 'viewport reports/matrix')
    backends = {}
    for report in reports:
        method = Path(report['views']['top']['before_path']).parent.name
        require(method in METHODS and method not in backends, 'viewport backend')
        require(report['pass'] is True and report['mode'] == 'managed' and report['viewport_ready'] is True and all(value is True for value in report['checks'].values()), 'viewport checks')
        require(report['external_scene_connection'] == 'not-present' and report['pair_membership'] == 'not-observed', 'viewport evidence boundary')
        require(set(report['views']) == {'top', 'side'}, 'viewport views')
        startup = re.findall(rf'^Metal [0-9.]+ - {re.escape(METHODS[method])} - Using Device #[0-9]+: .+$', text, re.M)
        require(len(startup) == 1, 'viewport actual renderer')
        views = {}
        for view, values in report['views'].items():
            images = {}
            for phase in ('before', 'after'):
                require(values[phase + '_draw_calls'] == 2, 'viewport two draw calls')
                item = {key: values[key] for key in ('saved', 'width', 'height')}
                item.update({key: values[phase + '_' + key] for key in ('path', 'sha256', 'nonuniform_pixels')})
                images[phase] = image_review(item, evidence / 'final_viewport_gpu' / method, records)
            require(values['rgba_equal'] is True and images['before'] == images['after'], f'viewport RGBA before/after mismatch {method}/{view}')
            views[view] = {'before_after_rgba_equal': True, 'draw_calls_each': 2, 'nonuniform_pixels_each': values['before_nonuniform_pixels']}
        backends[method] = {'renderer_device': startup[0], 'views': views, 'all_reported_checks_true': True}
    require(set(backends) == set(METHODS), 'viewport method set')
    return {'log': identity, 'runner_exit_code': 0, 'backends': backends}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = {'status': 'FAIL', 'mode': 'offline-standard-library-no-GPU', 'images': []}
    try:
        result['decoder_self_test'] = decoder_self_test()
        green_images, result['green'] = camera_review(args.evidence.resolve(), True, result['images'])
        red_images, result['red'] = camera_review(args.evidence.resolve(), False, result['images'])
        for method in METHODS:
            for label in ('unregistered', 'first', 'second'):
                require(red_images[method][label] == green_images[method][label], f'RED/GREEN ordinary image changed: {method}/{label}')
        result['red_green_all_six_rgba_equal'] = True
        result['viewport'] = viewport_review(args.evidence.resolve(), result['images'])
        require(len(result['images']) == 20, 'expected 6 GREEN + 6 RED + 8 viewport PNGs')
        result['decoded_png_count'] = len(result['images'])
        result['status'] = 'PASS'
    except (OSError, ValueError, KeyError, TypeError, StopIteration, zlib.error) as error:
        result['error'] = f'{type(error).__name__}: {error}'
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'decoded_png_count': result.get('decoded_png_count'),
                      'error': result.get('error'), 'output': str(args.output.resolve())}))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)


if __name__ == '__main__':
    main()
