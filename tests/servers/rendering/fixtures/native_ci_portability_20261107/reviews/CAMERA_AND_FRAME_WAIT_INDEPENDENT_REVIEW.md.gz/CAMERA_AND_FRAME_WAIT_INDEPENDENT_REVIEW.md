# Independent source review

Verdict: no blocking source finding in the five-file native camera propagation slice or three-hunk FrameWait fixture fix. No source edits, build, runtime, sanitizer, or GPU run performed by this reviewer. Parent owns combined build and runtime evidence.

Source identity: SOURCE_IDENTITY.json records actual and manifest hashes. Three propagation files and FrameWait match exactly. Reconstructing the frozen SOURCE_CHANGE.patch against its base proves the other two changes are comment-only: acknowledgment spelling in render_data_rd.h and two spaces in the new test copyright filename line. POST_FREEZE_DIFF.patch preserves that exact difference. Semantic review applies to both versions; parent must associate build evidence with actual current hashes.

## Native camera propagation

- Caller chain: render_camera fully constructs local mono/XR CameraData, assigns the actual p_viewport RID before capture, then passes the same camera to cull _render_scene. Failed capture clears RID. Common RendererSceneRenderRD::render_scene populates one stack RenderDataRD and passes its address unchanged into the Mobile/Clustered virtual receiver. Ordinary zero-token calls avoid borrowing.
- Selection uses actual RID plus token, never global tuple search. Comparison covers every active camera field: center and eye matrices, view count bounds, flags, visibility and TAA. Value-copy validation precedes lazy retained Ref creation. An existing-retained repeat compares its original payload without dereferencing a freed RID.
- Retained Ref keeps original immutable sample alive after viewport advance/free. Later captures do not replace it. Getter hides on PacketIdentity tuple mismatch or retirement. Acknowledgement retires identity; receipt issuance only freezes mutations, so continued getter access before acknowledgement matches existing two-stage retirement. Physical Ref release remains scoped to RenderDataRD destruction or the last pass reference.
- Include dependency is acyclic: render_data_rd.h includes renderer_viewport.h, which includes renderer_scene_render.h; neither latter header includes render_data_rd.h. tests/SCsub recursively collects the new cpp and its TEST_FORCE_LINK is present.
- Tests cover mono/stereo lifetime and reference counts, rewritten second eye, ordinary zero-token/no allocation, 13 rewritten payload cases before allocation, repeat retain after RID free, tuple mismatch hiding, and retirement hiding. They call the common retention method directly; actual render_camera/backend wiring is source-inspected, not independently exercised by these tests. Explicit nonzero-wrong RID and view_id/epoch mutation cases would improve negative coverage but are nonblocking because these fields are already compared.

## FrameWait fixture

The prior second graph setup manually called graph.begin and set the primary flag. execute_chained_cmds advances qualification_issue_slot, while _stall_for_frame does not open a new epoch. The stale slot caused its one-command fake pool to index an absent chain semaphore. Actual _begin_frame waits, resets cursor/closed/busy state, begins the primary buffer, and starts the graph. New REQUIRE uses the real lifecycle.

Actual begin also drains attach() synthetic retained BufferID(61) through _free_pending_resources. Test-local ReuseDriver accepts only that exact buffer; shared driver remains fail-fast. record_next_graph has only this call site. Same buffer/slot, different graph, preserved serial23/new serial24, one callback, completed_size4, and OK assertions remain. No production source or assertion weakening.

Verification: scoped git diff --check exited0; source hashes recorded; frozen patch reconstruction succeeded. Author syntax-only evidence was read and is not runtime proof. Parent unit runtime and affected Linux ASan/TSan reruns remain the relevant next evidence.
