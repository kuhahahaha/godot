#pragma once
#include <cstdint>
class OS { public: static OS *get_singleton(); uint64_t get_ticks_usec() const; };
