#pragma once
#include <cstdint>
class Thread { public: static uint64_t get_caller_id(); };
