/**************************************************************************/
/*  register_types.cpp                                                    */
/**************************************************************************/
/*                         This file is part of:                          */
/*                             GODOT ENGINE                               */
/*                        https://godotengine.org                         */
/**************************************************************************/
/* Copyright (c) 2014-present Godot Engine contributors (see AUTHORS.md). */
/* Copyright (c) 2007-2014 Juan Linietsky, Ariel Manzur.                  */
/*                                                                        */
/* Permission is hereby granted, free of charge, to any person obtaining  */
/* a copy of this software and associated documentation files (the        */
/* "Software"), to deal in the Software without restriction, including    */
/* without limitation the rights to use, copy, modify, merge, publish,    */
/* distribute, sublicense, and/or sell copies of the Software, and to     */
/* permit persons to whom the Software is furnished to do so, subject to  */
/* the following conditions:                                              */
/*                                                                        */
/* The above copyright notice and this permission notice shall be         */
/* included in all copies or substantial portions of the Software.        */
/*                                                                        */
/* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,        */
/* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF     */
/* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. */
/* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY   */
/* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,   */
/* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE      */
/* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.                 */
/**************************************************************************/

#include "register_types.h"

#include "native_depth_allocation_test_fixture.h"
#include "particles_external_guard_test_fixture.h"
#include "particles_external_output_test_fixture.h"
#include "particles_heightfield_clear_test_fixture.h"
#include "particles_runtime_test_fixture.h"
#include "particles_scene_pairs_test_fixture.h"

#include "core/object/class_db.h"
void initialize_particles_runtime_tests_module(ModuleInitializationLevel p_level) {
	if (p_level == MODULE_INITIALIZATION_LEVEL_SCENE) {
		GDREGISTER_CLASS(NativeDepthAllocationTestFixture);
		GDREGISTER_CLASS(ParticlesRuntimeTestFixture);
		GDREGISTER_CLASS(ParticlesHeightfieldClearTestFixture);
		GDREGISTER_CLASS(ParticlesExternalGuardTestFixture);
		GDREGISTER_CLASS(ParticlesExternalOutputTestFixture);
		GDREGISTER_CLASS(ParticlesHeightfieldClearTestFixture);
		GDREGISTER_CLASS(ParticlesScenePairsTestFixture);
	}
}
void uninitialize_particles_runtime_tests_module(ModuleInitializationLevel p_level) {}
